#!/bin/sh
VBoxManage startvm Centos1 --type headless
